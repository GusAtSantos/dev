@extends('layouts.app')

@section('conteudo')
<form action="/store" method="post">
    @csrf
    <p>
        <label for="nome_do_veiculo">Veiculo</label>
        <input type="Text" id="nome_do_veiculo" name="nome_do_veiculo" value="">
    </p>
    <p>
        <label for="marca">Marca</label>
        <input type="text" id="marca" name="marca" value="">
    </p>
    <p>
        <label for="ano">ano</label>
        <input type="number" id="ano" name="ano" value="">
    </p>
    <p>
        <label for="preco">preço</label>
        <input type="number" id="preco" name="preco" value="">
    </p>
    <p>
        <label for="qualidade">qualidade</label>
        <input type="text" id="qualidade" name="qualidade" value="">
    </p>
    <p>
        <button type="submit">Anunciar</button>
    </p>
</form>
@endsection
