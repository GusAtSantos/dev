<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora</title>
</head>
<body>
    <?php if(Auth::check()): ?>
        <a href="/logout">Sair</a>
        <hr>
    <?php endif; ?>

    <?php echo $__env->yieldContent('conteudo'); ?>
</body>
</html><?php /**PATH C:\Users\fernandoluiz\Documents\calculadora-mvc-laravel-3B1\resources\views/layouts/app.blade.php ENDPATH**/ ?>