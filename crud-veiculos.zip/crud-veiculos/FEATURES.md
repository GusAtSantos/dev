/ -> listar opera��es matematicas que foram realizadas e armazenadas no banco de dados

/create -> criar um formul�rio com dois inputs n�mericos e um de sele��o para opera��o e submeter esses dados via post

/store -> fazer a opera��o matem�tica e armazen�-la no banco de dados

