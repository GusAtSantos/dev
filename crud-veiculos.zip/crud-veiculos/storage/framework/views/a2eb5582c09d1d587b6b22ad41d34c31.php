

<?php $__env->startSection('conteudo'); ?>
<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($e); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<form action="/authenticate" method="post">
    <?php echo csrf_field(); ?>
    <p>
        E-mail: <input type="text" name="email" value="<?php echo e(old('email')); ?>">
    </p>
    <p>
        Senha: <input type="password" name="password" value="">
    </p>    
    <p>
        <button type="submit">Logar</button>
    </p>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Documents\calculadora-mvc-laravel-3B1\resources\views/login.blade.php ENDPATH**/ ?>