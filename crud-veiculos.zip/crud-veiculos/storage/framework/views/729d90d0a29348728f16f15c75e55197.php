

<?php $__env->startSection('conteudo'); ?>
<form action="/store" method="post">
    <?php echo csrf_field(); ?>
    <p>
        <label for="nome_do_veiculo">Veiculo</label>
        <input type="Text" id="nome_do_veiculo" name="nome_do_veiculo" value="">
    </p>
    <p>
        <label for="marca">Marca</label>
        <input type="text" id="marca" name="marca" value="">
    </p>
    <p>
        <label for="ano">ano</label>
        <input type="number" id="ano" name="ano" value="">
    </p>
    <p>
        <label for="preco">preço</label>
        <input type="number" id="preco" name="preco" value="">
    </p>
    <p>
        <label for="qualidade">qualidade</label>
        <input type="text" id="qualidade" name="qualidade" value="">
    </p>
    <p>
        <button type="submit">Anunciar</button>
    </p>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\www\crud-veiculos\crud-veiculos\resources\views/formulario.blade.php ENDPATH**/ ?>