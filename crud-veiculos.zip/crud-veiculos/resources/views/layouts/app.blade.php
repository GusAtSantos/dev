<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veiculos</title>
   <style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f9f9f9;
    
}

.container {
    display: flex;
    justify-content: center;
}

.btn_c{
     margin-right:2000px;
}

h1 {
    text-align: center;
    color: #333;
}

a {
    display: block;
    width: 150px;
    margin: 20px auto;
    padding: 10px 20px;
    background-color: #007bff;
    color: #fff;
    text-align: center;
    text-decoration: none;
    border-radius: 5px;
}


/* Estilos da tabela */
table {
    width: 50%;
    border-collapse: collapse;
    margin: 20px 0;
    background-color: #fff;
}

th, td {
    padding: 5px;
    text-align: center;
    border: 1px solid #ddd;
}

th {
    background-color: #f2f2f2;
}

tr:nth-child(even) {
    background-color: #f9f9f9;
}



svg{
    width: 1em;
    
}
   </style>
</head>
<body>
<h2>Crud veiculos</h2>
<hr>
    @yield('conteudo')
</body>
</html>