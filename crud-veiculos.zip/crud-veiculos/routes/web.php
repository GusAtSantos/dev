<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\VeiculosController;

Route::get('/', [VeiculosController::class, 'index']);
Route::get('/create', [VeiculosController::class, 'create']);
Route::get('/edit', [VeiculosController::class, 'edit']);
Route::post('/update', [VeiculosController::class, 'update']);
Route::post('/store', [VeiculosController::class, 'store']);
Route::delete('/delete', [VeiculosController::class, 'delete']);

